package com.roitraining.demo.reactive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
