package com.roitraining.demo.reactive.enums;

public enum OrderStatus {
    ORDERED, IN_TRANSIT, DELIVERED, CANCELLED, RETURNED
}
